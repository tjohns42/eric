<!-- Begin footer.php -->
  <footer>
    <?php wp_footer(); ?>
    <p>
      Copyright &copy; <?php echo date( " Y " ); bloginfo('name'); ?> | All Rights Reserved.
    </p>
  </footer>
</div><!-- End container -->
</body>
</html>