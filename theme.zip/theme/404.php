<?php get_header(); ?>
<!-- Begin home.php -->
  <div class="main">
    <div class="content">
      <h2>404: Page Not Found</h2>
    </div>
    <?php get_sidebar(); ?>
    <div class="clear"></div>
  </div>
<?php get_footer(); ?>
<!-- End home.php -->